import static java.lang.Math.sqrt;
import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    questao01();
    questao02();
    questao03();
    questao04();
    questao05();
    questao06();
  }
  public static void questao01(){
     float troco;
     Scanner teclado = new Scanner(System.in);
     System.out.println("Informe o valor pago:");
     float precoPago = teclado.nextFloat();
     System.out.println("Informe o valor do produto: ");
     float precoProduto = teclado.nextFloat();
     troco= precoPago - precoProduto;
     System.out.println("Este é p troco: " +troco);
   }
  public static void questao02(){
    float a,b,c;
    float xUm, xDois;
    Scanner teclado = new Scanner(System.in);
    System.out.println("Escreva o valor de 'A'");
    a = teclado.nextFloat();
    System.out.println("Escreva o valor de 'B'");
    b = teclado.nextFloat();
    System.out.println("Escreva o valor de 'C'");
    c = teclado.nextFloat();
    float delta = b*b - 4*a*c;
    xUm = -b + mat.sqrt(delta) / 2*a;
    xDois = -b - mat.sqrt(delta) / 2*a;
    System.out.println("O valor de 'x' é: "+xUm);

    System.out.println("O valor de 'x'' é: "+xDois);

  }

  public static void questao03(){
    float pesoExedente, multa; 
    Scanner teclado = new Scanner(System.in);
    System.out.println("Informe o peso dos peixes: ");
    float pesoPeixes = teclado.nextFloat();
    if (pesoPeixes > 50){
      pesoExedente = pesoPeixes - 50;
         multa = pesoExedente * 4;  
      }
      else {
        multa = 0;
        pesoExedente = 0;
      }
    System.out.println("Multa:" +multa);
    System.out.println("Peso exedente: "+pesoExedente);

  }
  public static void questao04(){
    double s;
    int x;
    Scanner teclado = new Scanner(System.in);
    System.out.println("Informe o valor de N: ");
    int n = teclado.nextInt();
    x = n;
    while (n>1) {
      x *= (n - 1);
      n--;
    }
    s = 1 + 0.5 + 0.17 + 1/x;
    System.out.println("O valor de S: " + s);
  }
  public static void questao05(){
  }
  public static void questao06(){
    int x;
    do{
      Scanner teclado = new Scanner(System.in);
      System.out.println("Informe o valor de m: ");
      int m = teclado.nextInt();
          x = m;
      if(m < 10) {
        while(m > 1){
          x *= (m - 1);
          m--;
        }
        System.out.println(""+m);

      }else {
        System.out.print("Esse número é divisível por + infinito até -infinito.");
      }
    }while(m != 0 && m > 0);

  }


}
 
 